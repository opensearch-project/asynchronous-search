## Version 1.1.0.0 Release Notes

Compatible with OpenSearch 1.1.0

### Infrastructure

* Fix snapshot build and increment to 1.1.0 ([#31](https://github.com/opensearch-project/asynchronous-search/pull/31))

### Bug Fixes

* Fix: typo in flag name. ([#32](https://github.com/opensearch-project/asynchronous-search/pull/32))

