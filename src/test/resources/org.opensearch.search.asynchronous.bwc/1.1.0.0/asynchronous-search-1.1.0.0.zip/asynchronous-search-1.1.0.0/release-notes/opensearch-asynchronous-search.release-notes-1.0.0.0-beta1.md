## Version 1.0.0.0-beta1 2021-04-26

Compatible with OpenSearch 1.0.0

### Infrastructure
  * Adds templates for PR, bug report and feature request ([#5](https://github.com/opensearch-project/asynchronous-search/pull/5))
  * Changes to use OpenSearch 1.0.0-alpha1 ([#6](https://github.com/opensearch-project/asynchronous-search/pull/6))
### Documentation
  * Update licenses ([#4](https://github.com/opensearch-project/asynchronous-search/pull/4))
### Refactoring
  * Update version to 1.0.0.0-beta1 ([#8](https://github.com/opensearch-project/asynchronous-search/pull/8))
